program UCalc;

uses
  Forms,
  Unit_Calculadora in 'Unit_Calculadora.pas' {FrmCalc},
  USobre in 'USobre.pas' {FrmSobre},
  UTranp in 'UTranp.pas' {FrmTransp};

{$R *.res}

begin
  Application.Initialize;
  Application.Title := 'Calculadora';
  Application.CreateForm(TFrmCalc, FrmCalc);
  Application.CreateForm(TFrmSobre, FrmSobre);
  Application.Run;
end.
