unit USobre;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ExtCtrls, ComCtrls;

type
  TFrmSobre = class(TForm)
    Panel1: TPanel;
    ProgramIcon: TImage;
    ProductName: TLabel;
    Version: TLabel;
    Copyright: TLabel;
    OKButton: TButton;
    RichEdit1: TRichEdit;
    procedure OKButtonClick(Sender: TObject);




  private
    { Private declarations }

  public
    { Public declarations }
  end;

var
  FrmSobre: TFrmSobre;

implementation

uses Unit_Calculadora;

{$R *.dfm}

procedure TFrmSobre.OKButtonClick(Sender: TObject);
begin
close;
frmcalc.Show;
end;

end.

