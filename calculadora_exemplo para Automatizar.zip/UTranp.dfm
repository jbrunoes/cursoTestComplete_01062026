object FrmTransp: TFrmTransp
  Left = 328
  Top = 320
  Width = 313
  Height = 99
  BorderStyle = bsSizeToolWin
  Caption = 'Definindo a Transparencia '
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object TrackBar1: TTrackBar
    Left = 0
    Top = 8
    Width = 297
    Height = 45
    Position = 10
    TabOrder = 0
    OnChange = TrackBar1Change
  end
end
