unit Unit_Calculadora;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Menus, ComCtrls, Buttons, ExtCtrls, XP_Form,
  ToolWin, XP_Button, WinXP ;

type
  TFrmCalc = class(TForm)
    WinXP1: TWinXP;
    Btn9: TSpeedButton;
    BtnBackSpace: TSpeedButton;
    BtnC: TSpeedButton;
    Btn4: TSpeedButton;
    Btn5: TSpeedButton;
    Btn6: TSpeedButton;
    Btn1: TSpeedButton;
    Btn2: TSpeedButton;
    Btn3: TSpeedButton;
    Btn0: TSpeedButton;
    BtnV: TSpeedButton;
    BtnIgual: TSpeedButton;
    BtnMais: TSpeedButton;
    BtnMenos: TSpeedButton;
    BtnX: TSpeedButton;
    BtnD: TSpeedButton;
    SpeedButton1: TSpeedButton;
    SpeedButton2: TSpeedButton;
    SpeedButton5: TSpeedButton;
    edt: TEdit;
    Btn8: TSpeedButton;
    Btn7: TSpeedButton;
    MainMenu1: TMainMenu;
    Edit1: TMenuItem;
    Copy1: TMenuItem;
    ransparencia1: TMenuItem;
    Sair1: TMenuItem;
    Sobre1: TMenuItem;
    SpeedButton3: TSpeedButton;
    ConfiguracaodoSobre1: TMenuItem;
    VirdoCentro1: TMenuItem;
    AparecerdeCimaparaBaixo1: TMenuItem;
    AparecerdeBaixoparaCima1: TMenuItem;
    tornarseVisivel: TMenuItem;
    procedure FormShow(Sender: TObject);
    procedure BtnXClick(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure soma;
    procedure subtracao;
    procedure multiplicacao;
    procedure divisao;
    procedure percentual;
    procedure Expoente;
    procedure BtnBackSpaceClick(Sender: TObject);
    procedure BtnCClick(Sender: TObject);
    procedure Btn4Click(Sender: TObject);
    procedure Btn5Click(Sender: TObject);
    procedure Btn6Click(Sender: TObject);
    procedure Btn1Click(Sender: TObject);
    procedure Btn2Click(Sender: TObject);
    procedure Btn3Click(Sender: TObject);
    procedure Btn0Click(Sender: TObject);
    procedure BtnvClick(Sender: TObject);
    procedure BtnIgualClick(Sender: TObject);
    procedure BtnMaisClick(Sender: TObject);
    procedure BtnMenosClick(Sender: TObject);
    procedure BtnDClick(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton5Click(Sender: TObject);
    procedure Sobre1Click(Sender: TObject);
    procedure RetornaOperador(Vl: char);
    procedure FormCreate(Sender: TObject);
    procedure ransparencia2Click(Sender: TObject);
    procedure Copy2Click(Sender: TObject);
    procedure Sair2Click(Sender: TObject);
    procedure Sair1Click(Sender: TObject);
    procedure ransparencia1Click(Sender: TObject);
    procedure Copy1Click(Sender: TObject);
    procedure Btn7Click(Sender: TObject);
    procedure Btn8Click(Sender: TObject);
    procedure Btn9Click(Sender: TObject);

  private
    kFloat : Extended;
    visor:Extended;
    ToDo : Boolean;
    fst : Boolean;
    operacao:char;
    resultado:Extended;
    myNumber: Extended;
    no : Extended;
    vp : string;
    strVer : cardinal;
  public


  end;

  var
  FrmCalc: TFrmCalc;


implementation

uses Math, USobre, UTranp;

{$R *.dfm}

procedure TFrmCalc.FormShow(Sender: TObject);
begin
visor:=0;
mynumber:=0;
fst:=true;
end;

procedure TFrmCalc.BtnXClick(Sender: TObject);
begin
 RetornaOperador('*');
end;

procedure TFrmCalc.soma;
begin
if visor <> 0 then
  begin
   resultado:=visor+mynumber;
   edt.text:=floattostr(resultado);
   edt.Tag:=1;
   visor:=strtofloat(edt.Text);
  end
else
 begin
  visor:=strtofloat(edt.Text);
  mynumber:=StrToFloat(edt.text);
  edt.tag:=1;
 end;
end;

procedure TFrmCalc.subtracao;
begin
if visor <> 0 then
  begin
   resultado:=visor-mynumber;
   edt.text:=floattostr(resultado);
   edt.Tag:=1;
   visor:=strtofloat(edt.Text);
  end
  else
   begin
   visor:=StrToFloat(edt.Text);
   mynumber:=StrToFloat(edt.text);
   edt.tag:=1;
  end;
end;

procedure TFrmCalc.Expoente;
begin
 if edt.text <> '' then
  begin
   resultado:=power(visor,strtofloat(edt.Text));
   edt.text:=floattostr(resultado);
  end
 else
   edt.Text:=floattostr(visor);
   visor:=0;
end;

procedure TFrmCalc.multiplicacao;
begin
 if visor <> 0 then
  begin
   resultado:=visor*mynumber;
   edt.text:=floattostr(resultado);
   edt.Tag:=1;
   visor:=strtofloat(edt.Text);
  end
 else
   begin
       visor:=StrToFloat(edt.Text);
       mynumber:=StrToFloat(edt.text);
       edt.tag:=1;
   end;
end;

procedure TFrmCalc.divisao;
begin
 if visor <> 0 then
  begin
   resultado:=visor/mynumber;
   edt.text:=floattostr(resultado);
   edt.Tag:=1;
   visor:=strtofloat(edt.Text);
  end
 else
  begin
    visor:=StrToFloat(edt.Text);
    mynumber:=StrToFloat(edt.text);
    edt.tag:=1;
  end;
end;

procedure TFrmCalc.percentual;
begin
 if visor <> 0 then
  begin
   resultado:=visor/100 * mynumber;
   edt.text:=FloatToStr(resultado);
   edt.Tag:=1;
   visor:=strtofloat(edt.Text);
  end
 else
  begin
   visor:=StrToFloat(edt.Text);
   mynumber:=StrToFloat(edt.text);
   edt.tag:=1;
  end;
end;


procedure TFrmCalc.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin

if (key = 96) or (key = 48) then
 Btn0.click;
if (key = 97) or (key = 49) then
 btn1.click;
if (key = 98) or (key = 50) then
 btn2.click;
if (key = 99) or (key = 51) then
 btn3.click;
if (key = 100) or (key = 52) then
 btn4.Click;
if (key = 101) or (key = 53) then
 btn5.Click;
if (key = 102) or (key = 54) then
 btn6.Click;
if (key = 103) or (key = 55) then
 btn7.Click;
if (key = 104) or (key = 56) then
 btn8.click;
if (key = 105) or (key = 57) then
 btn9.Click;
if key = 107 then
 BtnMais.Click;
if key = 109 then
 BtnMenos.click;
if key = 111 then
 BtnD.click;
if key = 13 then
 BtnIgual.Click;
if key = 106 then
 BtnX.Click;
if key = 110 then
 Btnv.Click;
if key = 67 then
 btnc.click;
if key = 27 then
 btnc.Click;
if key = 8 then
 BtnBackSpace.click;

end;


procedure TFrmCalc.BtnBackSpaceClick(Sender: TObject);
begin
if edt.text <> '' then
 edt.text:=copy(edt.text,1,length(edt.text)-1);
end;

procedure TFrmCalc.BtnCClick(Sender: TObject);
begin
edt.clear;
visor:=0;
mynumber:=0;
operacao:=' ';
resultado:=0;
fst:=true;
end;

procedure TFrmCalc.Btn4Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;
 edt.text:=edt.text + '4';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;
end;

procedure TFrmCalc.Btn5Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;
 edt.text:=edt.text + '5';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;
end;

procedure TFrmCalc.Btn6Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;
 edt.text:=edt.text + '6';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;
end;

procedure TFrmCalc.Btn1Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
  end;

 edt.text:=edt.text + '1';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;
end;

procedure TFrmCalc.Btn2Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;
 edt.text:=edt.text + '2';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;
end;

procedure TFrmCalc.Btn3Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;
 edt.text:=edt.text + '3';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;
end;

procedure TFrmCalc.Btn0Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;
 edt.text:=edt.text + '0';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;
end;

procedure TFrmCalc.BtnvClick(Sender: TObject);
begin
if edt.tag <> 0 then
 begin
   edt.tag :=0;
   edt.clear;
 end;
 if pos(',', floattostr(kfloat)) <> 0 then
  begin
   if pos(',',edt.text)=0 then
     begin
      edt.text:=edt.text +',';
      btnv.Caption:=',';
     end;
  end;

 if pos('.', floattostr(kfloat)) <> 0 then
  begin
   if pos('.',edt.text)=0 then
     begin
       edt.text:=edt.text +'.';
       btnv.Caption:='.';
     end;
  end;

 if pos(',', edt.Text) or pos('.', edt.text) <> 0 then
   exit;

 edt.tag:=0;
 ToDo:=True;
end;

procedure TFrmCalc.BtnIgualClick(Sender: TObject);
begin
 case operacao of
  '+': soma;
  '-': subtracao;
  '*': multiplicacao;
  '/': divisao;
  '%': percentual;
  '#':expoente;

 else
   exit;
 end ;
  ToDo:=false;
end;

procedure TFrmCalc.BtnMaisClick(Sender: TObject);
begin
 RetornaOperador('+');
end;


procedure TFrmCalc.BtnMenosClick(Sender: TObject);
begin
 RetornaOperador('-');

end;


procedure TFrmCalc.BtnDClick(Sender: TObject);
begin
 RetornaOperador('/');
end;

procedure TFrmCalc.SpeedButton1Click(Sender: TObject);
var
raiz :string;
begin
if edt.text = '' then exit;

 if edt.text<>'' then
  if visor = 0 then
    visor:=strtofloat(edt.text)
   else
     visor:=visor-strtofloat(edt.text);

 edt.Tag:=1;
 Str(Sqrt(visor):5:4, Raiz);
 edt.Text:=Raiz;
end;

procedure TFrmCalc.SpeedButton2Click(Sender: TObject);
var
  myn: Integer;
begin
  myn:=strToInt(edt.text);
  edt.text:=IntToHex(myn,2);
end;

procedure TFrmCalc.SpeedButton5Click(Sender: TObject);
begin
 if edt.text = '' then
  exit;
   if no >= 0 then
    begin
       no      := StrToFloat(Edt.Text);
       no      := no *(-1);
       edt.text:=FloatToStr(no);
       visor   :=no;
    end
   else
    begin
        no      := StrToFloat(Edt.Text);
        no      := no * (-1)  ;
        edt.text:=FloatToStr(no);
        visor   :=no;
    end;
end;

procedure TFrmCalc.Sobre1Click(Sender: TObject);
begin
 if FrmCalc.VirdoCentro1.Checked             = true then strVer:= AW_CENTER;
 if FrmCalc.AparecerdeCimaparaBaixo1.Checked = true then strVer:= AW_VER_POSITIVE;
 if Frmcalc.AparecerdeBaixoparaCima1.checked = true then strVer:= AW_VER_NEGATIVE;
 if FrmCalc.tornarseVisivel.checked          = true then strVer:=AW_BLEND;
 frmcalc.Hide;
 AnimateWindow(FrmSobre.Handle,2000,strVer);
 Frmsobre.show;
end;

procedure TFrmCalc.RetornaOperador(Vl: char);
begin
if edt.Text = '' then exit;
if fst then
  begin
   operacao:=vl;
   BtnIgual.Click;
   fst:=false
end;
if ToDo then
 BtnIgual.Click;

ToDo :=False;
operacao:=vl;
end;

procedure TFrmCalc.FormCreate(Sender: TObject);
begin
   kFloat:=0.2 + 5.3;

   if pos(',', floattostr(kfloat)) = 0 then
    begin
      btnv.Caption:='.';
      vp:='.';
    end;
 if pos('.', floattostr(kfloat)) = 0 then
  begin
    btnv.Caption:=',';
    vp:=',';
  end;
end;

procedure TFrmCalc.ransparencia2Click(Sender: TObject);
begin
Application.CreateForm(TFrmTransp, FrmTransp);
FrmTransp.ShowModal;
FreeAndNil(FrmTransp);
end;

procedure TFrmCalc.Copy2Click(Sender: TObject);
begin
 edt.SelectAll;
 edt.CopyToClipboard;
end;

procedure TFrmCalc.Sair2Click(Sender: TObject);
begin
 Application.terminate;
end;

procedure TFrmCalc.Sair1Click(Sender: TObject);
begin
application.terminate;
end;

procedure TFrmCalc.ransparencia1Click(Sender: TObject);
begin
application.createform(TFrmTransp, frmtransp);
frmtransp.showmodal;
freeandnil(frmtransp);
end;

procedure TFrmCalc.Copy1Click(Sender: TObject);
begin
edt.SelectAll;
edt.CopyToClipboard;
end;

procedure TFrmCalc.Btn7Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;

 edt.text:=edt.text + '7';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;

end;

procedure TFrmCalc.Btn8Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;

 edt.text:=edt.text + '8';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;

end;

procedure TFrmCalc.Btn9Click(Sender: TObject);
begin
if edt.Tag <> 0 then
  begin
   edt.tag :=0;
   edt.clear;
end;

 edt.text:=edt.text + '9';
 myNumber:=StrTofloat(edt.text);
 ToDo:=True;

end;

end.

