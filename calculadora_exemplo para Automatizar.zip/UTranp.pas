unit UTranp;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ComCtrls;

type
  TFrmTransp = class(TForm)
    TrackBar1: TTrackBar;
    procedure TrackBar1Change(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FrmTransp: TFrmTransp;

implementation

uses Unit_Calculadora;

{$R *.dfm}

procedure TFrmTransp.TrackBar1Change(Sender: TObject);
begin
if TrackBar1.Position = 10 then
 FrmCalc.AlphaBlendValue:= 255
else
FrmCalc.AlphaBlendValue:=TrackBar1.Position * 20;
end;

end.
